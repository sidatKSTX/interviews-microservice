package com.consultingfirm.interviews.model;

public class InterviewsInfo {

}