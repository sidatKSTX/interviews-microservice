package com.consultingfirm.interviews.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class InterviewsController {
}