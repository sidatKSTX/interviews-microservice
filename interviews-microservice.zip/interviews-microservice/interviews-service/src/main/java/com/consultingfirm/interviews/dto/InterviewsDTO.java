package com.consultingfirm.interviews.dto;

public class InterviewsDTO {

}