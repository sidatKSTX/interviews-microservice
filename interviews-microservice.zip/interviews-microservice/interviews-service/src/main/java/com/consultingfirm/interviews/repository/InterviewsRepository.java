package com.consultingfirm.interviews.repository;

public interface InterviewsRepository {

}