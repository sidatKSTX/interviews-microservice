package com.consultingfirm.interviews.service;

public interface InterviewsService {
}
